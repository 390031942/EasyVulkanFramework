#pragma once
#include "Draggable.h"
class PositionHandle :public AbstractDraggable
{
public:
	enum Axis {x = 0,y = 1};

};

