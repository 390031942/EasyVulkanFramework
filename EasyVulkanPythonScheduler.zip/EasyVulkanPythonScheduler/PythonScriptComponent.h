#pragma once
#include "Component.h"

#include <map>
#include <string>
#include <boost/python.hpp>

class PythonInternalMethodMap
{

private:
	const int METHOD_START = 0x01;
	const int METHOD_UPDATE = 0x02;

	std::map<std::string, bool> methodMap;

public:
	PythonInternalMethodMap() { 
		methodMap["Start"] = false;
		methodMap["Update"] = false;
	}

	void setStart(bool declared)
	{
		methodMap["Start"] = declared;
	}

	bool getStart()
	{
		return methodMap["Start"];
	}

	void setUpdate(bool declared)
	{
		methodMap["Update"] = declared;
	}

	bool getUpdate()
	{
		return methodMap["Update"];
	}

};

class PythonVariableTypeMap
{

};
class PythonModuleVariableInfo
{
	int         variableTypeID;
	std::string variableName;
};
class PythonModuleInfo
{
	PythonInternalMethodMap methodMap;
	std::vector<PythonModuleVariableInfo> varInfo;

	bool IsStartCallable()
	{

	}

	bool IsUpdateCallable()
	{

	}
};
class PythonScriptComponent :public Component
{
public:
	boost::python::object module;

	void setProperty();

	void getProperty();

	void invoke(std::string methodName,...);
};

