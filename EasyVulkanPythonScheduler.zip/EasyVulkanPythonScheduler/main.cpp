#include <QtCore/QCoreApplication>

#include <Python.h>
#include <boost/python.hpp>
#include <iostream>
using namespace std;
using namespace boost::python;

class testClass
{
private:
	string str;
public:
	string GetString()
	{
		return str;
	}

	void SetString(string str)
	{
		this->str = str;
	}

	void Internal_Method()
	{
		str = "after internal Call";
	}
};


int main(int argc, char *argv[])
{
	QCoreApplication a(argc, argv);
	typedef boost::shared_ptr<testClass> testClass_PTR; 
	Py_Initialize();
	if (Py_IsInitialized())
	{
		try
		{
			PyObject* pModule = PyImport_ImportModule("EasyVulkan_PyWrapper");

//			register_ptr_to_python<testClass_PTR>();

			PyRun_SimpleString("import sys");
			PyRun_SimpleString("sys.path.append('./')");

			object module = object(handle<>(borrowed(PyImport_AddModule("__main__"))));
			object main_namespace = module.attr("__dict__");

			exec("from EasyVulkan_PyWrapper import testClass", main_namespace, main_namespace);
			exec("testClassInst = testClass()", main_namespace, main_namespace);
			testClass* testClassInst = extract<testClass*>(main_namespace["testClassInst"]);

			testClassInst->Internal_Method();
			exec("print(testClassInst.GetString())", main_namespace, main_namespace);

			/*dict["testClassInst"] = testclass_ptr;

			char* file_ptr = "test.py";
			testClassInst->SetString("wo aini !");
			exec_file(file_ptr, dict, dict);

			std::cout << testClassInst->GetString() << std::endl;*/

			/*char* file_ptr = "test1.py";

			dict LocalDict = dict();
			exec_file(file_ptr, main_namespace, LocalDict);
	
			object obj1 = LocalDict["testClassInst"];
			testClass result = extract<testClass>(obj1);

			dict LocalDict1 = dict();
			exec_file(file_ptr, main_namespace, LocalDict1);

			object obj2 = LocalDict1["testClassInst"];
			testClass result2 = extract<testClass>(obj2);*/



		}
		catch (error_already_set e)
		{
			PyErr_Print();
		}
	}
	Py_Finalize();
	return a.exec();
}
