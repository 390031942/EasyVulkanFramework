#pragma once
#include <string>

class Component
{
public:
	bool enabled;
	std::string name;
};

