from EasyVulkan_PyWrapper import testClass
import random

testClassInst = testClass()
testClassInst.SetString(''.join(random.sample(['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a'], 5)))