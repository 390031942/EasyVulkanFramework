from EasyVulkan_PyWrapper import testClass

print(testClassInst.GetString())